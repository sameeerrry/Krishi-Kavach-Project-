import { React} from 'react'
import './App.css'
import ShowData from './components/Homepage/Homepage'

function App() {
  return (
    <>
    <ShowData/>
    </>
  )
}

export default App
